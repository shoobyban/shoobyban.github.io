<?php
/**

Minimalist Magento admin Grid without the need of table structure

Copyright (c) 2012 Szabolcs (Sam) Ban <szabolcs.ban@wizguild.com>

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/

class Wizguild_VirtualGrid_Adminhtml_IndexController extends Mage_Adminhtml_Controller_Action
{
    public function indexAction() {

		// we load the layout
        $this->loadLayout();

		// then create a block with the page design as template
        $block = $this->getLayout()->createBlock(
            'Mage_Core_Block_Template',
            'virtualgrid_block',
            array('template' => 'virtualgrid/index.phtml')
        );

		// we create a grid from Wizguild_VirtualGrid_Block_Grid as child
        $block->setChild('grid',
        		$this->getLayout()->createBlock(
        				'Wizguild_VirtualGrid_Block_Grid',
        				'virtualgrid_virtual_grid')
        		);

		// adding content to the layout
        $this->_addContent($block);

		// calling render
        $this->renderLayout();
        
    }

}