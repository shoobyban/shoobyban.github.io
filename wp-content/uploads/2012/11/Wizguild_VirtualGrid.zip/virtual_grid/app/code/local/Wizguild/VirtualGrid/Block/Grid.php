<?php
/**

Minimalist Magento admin Grid without the need of table structure

Copyright (c) 2012 Szabolcs (Sam) Ban <szabolcs.ban@wizguild.com>

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/

class Wizguild_VirtualGrid_Block_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    protected function _prepareCollection()
    {
        $collection = new Varien_Data_Collection();
        foreach (array('alpha','beta','charlie') as $item) {
            $data = new Varien_Object();
            $data->setName($item);
            $collection->addItem($data);
        }
        $this->setCollection($collection);
    }

    protected function _prepareColumns()
    {
        $this->addColumn('name',
            array(
                'header' => 'Name',
                'align' =>'left',
                'width' => '50px',
                'index' => 'name',
            ));
        return parent::_prepareColumns();
    }
}